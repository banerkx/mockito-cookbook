# PowerShell validator script would be here (from previous message)
