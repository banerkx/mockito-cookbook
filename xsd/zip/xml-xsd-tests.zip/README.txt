XML/XSD Validator Test Collection
=================================
This package contains 11 sets of XML and XSD files, ranging from simple to complex,
for testing XML Schema validation in PowerShell.

Sets 1-10: Local schema features.
Set 11: Remote import from W3C XML schema.

Usage:
  powershell -ExecutionPolicy Bypass -File .\Run-XmlValidator.ps1
